import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*欢迎使用学生成绩管理系统：
        1. 添加学生
        2. 显示全部学生
        3. 查找学生
        4. 修改学生成绩
        5. 删除学生
        6. 统计成绩
        7. 退出系统
        请输入你的选择：*/
        Student[] students = new Student[1];
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("欢迎使用学生成绩管理系统：");
            System.out.println("1. 添加学生");
            System.out.println("2. 显示全部学生");
            System.out.println("3. 查找学生");
            System.out.println("4. 修改学生成绩");
            System.out.println("5. 删除学生");
            System.out.println("6. 统计成绩");
            System.out.println("7. 退出系统");
            System.out.println("请输入你的选择：");
            int choose = sc.nextInt();
            if (choose == 1) {
                students = AddStudent(students);
            } else if (choose == 2) {
                ShowAllStudents(students);
            } else if (choose == 3) {
                System.out.println("1. ID查询");
                System.out.println("2. 名字查询");
                System.out.println("请输入你的选择：");
                int choose3 = sc.nextInt();
                if (choose3 == 1) {
                    System.out.println("输入查询的ID");
                    int searchID = sc.nextInt();
                    SearchStudent(students, searchID);
                } else if (choose3 == 2) {
                    System.out.println("输入查询的名字");
                    String searchName = sc.next();
                    SearchStudent(students, searchName);
                }
            } else if (choose == 4) {
                System.out.println("1. 根据ID修改");
                System.out.println("输入被修改者的ID");
                int searchID = sc.nextInt();
                ChangeStudentGrade(students,searchID);

            } else if (choose == 5) {
                System.out.println("输入删除学生的ID");
                int Del = sc.nextInt();
                DelStudent(students,Del);
            } else if (choose == 6) {
                SumGrade(students);
            } else if (choose == 7) {
                return;
            } else {
                System.out.println("输入内容不合法,请重新输入");
            }
        }
    }

    //1. 添加学生
    public static Student[] AddStudent(Student[] students) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入学生信息");
        System.out.println("请输入学生名字");
        String name = sc.next();
        System.out.println("请输入学生成绩");
        double grade = sc.nextDouble();
        System.out.println("请输入学生ID");
        int ID = sc.nextInt();
        Student student = new Student(name, grade, ID);
        int count = 0;
        for (int i = 0; i < students.length; i++) {
            if (students[i] == null) {
                boolean flag = CheckID(students, student.getID());
                if (flag) {
                    System.out.println("ID 重复,添加失败");
                } else {
                    students[i] = student;
                    System.out.println("添加成功");
                    break;
                }
            } else {
                count++;
            }
            boolean flag = CheckID(students, student.getID());
            if (flag) {
                System.out.println("ID 重复,添加失败");
                break;
            } else {
                if (count == students.length) {
                    Student[] studentsNew = new Student[students.length + 1];
                    for (int i1 = 0; i1 < students.length; i1++) {
                        studentsNew[i1] = students[i1];
                    }
                    studentsNew[count] = student;
                    System.out.println("添加成功");
                    return studentsNew;
                }
            }


        }
        System.out.println("按任意键返回--除空格键");
        String A = sc.next();
        return students;
    }

    //2. 显示全部学生
    public static void ShowAllStudents(Student[] students) {
        Scanner sc = new Scanner(System.in);
        System.out.println("====学生信息====");
        for (int i = 0; i < students.length; i++) {
            Student student = students[i];
            if (students[i] != null) {
                System.out.println("名字:" + student.getName() + " 成绩:" + student.getGrade() + " ID:" + student.getID());
            }
        }
        System.out.println("===============");
        System.out.println("按任意键返回--除空格键");
        String A = sc.next();
    }

    //1. 检查学号是否重复
    public static boolean CheckID(Student[] students, int ID) {
        for (int i = 0; i < students.length; i++) {
            Student student = students[i];
            if (students[i] != null) {
                if (ID == student.getID()) {
                    return true;
                }
            }

        }
        return false;
    }

    //3. 查找学生--1--ID search
    public static void SearchStudent(Student[] students, int ID) {
        Scanner sc = new Scanner(System.in);
        System.out.println("====学生信息====");
        for (int i = 0; i < students.length; i++) {
            Student student = students[i];
            if (students[i] != null) {
                if (student.getID() == ID) {
                    System.out.println("名字:" + student.getName() + " 成绩:" + student.getGrade() + " ID:" + student.getID());
                }
            }
        }
        System.out.println("===============");
        System.out.println("按任意键返回--除空格键");
        String A = sc.next();
    }

    //3. 查找学生--2--Name Search
    public static void SearchStudent(Student[] students, String name) {
        Scanner sc = new Scanner(System.in);
        System.out.println("====学生信息====");
        for (int i = 0; i < students.length; i++) {
            Student student = students[i];
            if (students[i] != null) {
                if (student.getName().equals(name)) {
                    System.out.println("名字:" + student.getName() + " 成绩:" + student.getGrade() + " ID:" + student.getID());
                }
            }
        }
        System.out.println("===============");
        System.out.println("按任意键返回--除空格键");
        String A = sc.next();
    }

    //4. 修改学生成绩--ID
    public static void ChangeStudentGrade(Student[] students, int ID) {
        Scanner sc = new Scanner(System.in);
        int count = 0;
        boolean flag = false;
        for (int i = 0; i < students.length; i++) {
            Student student = students[i];
            if (students[i] != null) {
                if (student.getID() == ID) {
                    System.out.println("====查询结果为====");
                    System.out.println("名字:" + student.getName() + " 成绩:" + student.getGrade() + " ID:" + student.getID());
                    System.out.println("================");
                    System.out.println("按1确认修改");
                    System.out.println("按2返回");
                    int input = sc.nextInt();
                    if (input == 1){
                        System.out.println("输入修改的成绩值");
                        double changeGrade = sc.nextDouble();
                        student.setGrade(changeGrade);
                        students[i] = student;
                        flag = true;
                        System.out.println("修改成功");
                        break;
                    } else if (input == 2) {
                        return;
                    }
                } else {
                    count++;
                }
            }
        }
        if (!flag) {
            System.out.println("查找对象不存在");
        }
        System.out.println("按任意键返回--除空格键");
        String A = sc.next();
    }
    public static void DelStudent(Student[] students,int ID){
        Scanner sc = new Scanner(System.in);
        boolean flag = false;
        for (int i = 0; i < students.length; i++) {
            Student student = students[i];
            if (students[i] != null){
                if (student.getID() == ID){
                    System.out.println("====查询结果为====");
                    System.out.println("名字:" + student.getName() + " 成绩:" + student.getGrade() + " ID:" + student.getID());
                    System.out.println("================");
                    System.out.println("按1确认删除");
                    System.out.println("按2返回");
                    int input = sc.nextInt();
                    if (input == 1) {
                        students[i] = null;
                        flag = true;
                        System.out.println("删除成功");
                        break;
                    } else if (input == 2) {
                        return;
                    }

                }
            }
        }
        if (!flag){
            System.out.println("无搜索结果,删除失败");
        }
        System.out.println("按任意键返回--除空格键");
        String A = sc.next();
    }
    public static void SumGrade(Student[] students){
        Scanner sc = new Scanner(System.in);
        Student max = students[0];
        double Sum = 0;
        int count = 0;
        for (int i = 0; i < students.length; i++) {
            if (students[i] != null){
                Student student = students[i];
                Sum += student.getGrade();
                count++;
            }
        }
        for (int i = 0; i < students.length; i++) {
            Student student = students[i];
            if (students[i] != null){
                if (student.getGrade() > max.getGrade()){
                    max.setGrade(student.getGrade());
                }
            }
        }
        double result1 = Sum / count;
        System.out.println("最高分为:" + max.getGrade());
        System.out.println("共存储学生数:" + count);
        System.out.println("平均成绩为" + result1);
        System.out.println("按任意键返回--除空格键");
        String A = sc.next();
    }
}